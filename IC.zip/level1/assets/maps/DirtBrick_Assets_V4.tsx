<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="DirtBrick_Assets_V4" tilewidth="16" tileheight="16" tilecount="320" columns="20">
 <image source="DirtBrick_Assets_V4.png" width="328" height="257"/>
</tileset>
