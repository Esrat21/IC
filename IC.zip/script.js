var url = window.location.href;

function lvl1(){
    url+="level1";
    window.location.replace(url)
}

function lvl2(){
    url+="level2";
    window.location.replace(url)
}